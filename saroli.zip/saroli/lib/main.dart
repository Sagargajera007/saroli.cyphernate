import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saroli/HomeScreen.dart';
import 'package:saroli/stock%20transfer/First_Page.dart';

void main() {
  runApp(MaterialApp(
    home: homescreen(),
    debugShowCheckedModeBanner: false,
  ));
}
